# Configuración de Supabase (Etapa 5, infraestructura)

## 1. Crear el proyecto
1. En https://supabase.com crea un proyecto nuevo y espera a que termine de aprovisionarse.
2. **Project Settings → API**: copia **Project URL** y la clave **anon public**. No uses `service_role`.

## 2. Base de datos, RLS y Storage (una sola migración)
1. **SQL Editor → New query**, pega el contenido de `supabase/migrations/20260101000000_init_store.sql` y ejecútalo (Run).
   Alternativa con la CLI: `supabase link --project-ref <ref>` y luego `supabase db push`.
2. Esto crea: tablas `beats`, `beat_licenses` y `admins`, índices, constraints, triggers de `updated_at`,
   políticas RLS, los buckets `covers` y `audio` y sus políticas de escritura (solo admin).

## 3. Auth: cerrar el registro y crear el primer administrador
1. **Authentication → Sign In / Providers → Email**: desactiva **Allow new users to sign up**.
2. **Authentication → Users → Add user → Create new user**: email y contraseña, marca **Auto Confirm User**.
3. Convierte a ese usuario en administrador (SQL Editor):
   ```sql
   insert into public.admins (user_id)
   select id from auth.users where email = 'tu@email.com';
   ```
   Sin este paso el usuario puede iniciar sesión pero **no puede escribir** nada (la base de datos lo rechaza).

## 4. Variables de entorno
```
cp .env.example .env      # rellena VITE_SUPABASE_URL y VITE_SUPABASE_ANON_KEY
```
`.env` ya está en `.gitignore`. Nunca subas claves al repositorio.

## 5. Añadir los archivos al proyecto Vite
```
npm install @supabase/supabase-js
```
Copia `src/config`, `src/lib` y `src/services` dentro de tu `src/`. Los componentes solo deben importar
`beatService`, `mediaService` y `authService`; nunca `supabase` directamente.

## 6. Verificación de seguridad (sustituye URL y clave)
```
# 1) El público solo ve beats visibles (no drafts ni hidden)
curl "$URL/rest/v1/beats?select=title,status" -H "apikey: $ANON" -H "Authorization: Bearer $ANON"

# 2) El público NO puede escribir: debe responder 401/403 o un error de RLS
curl -X POST "$URL/rest/v1/beats" -H "apikey: $ANON" -H "Authorization: Bearer $ANON" \
  -H "Content-Type: application/json" -d '{"title":"x","slug":"x"}'

# 3) La tabla admins no es accesible: debe responder error de permisos
curl "$URL/rest/v1/admins" -H "apikey: $ANON" -H "Authorization: Bearer $ANON"
```
Comprueba también que un usuario autenticado que **no** esté en `admins` recibe error al insertar.

## Checklist
- [ ] No hay `service_role` en el frontend
- [ ] `.env` ignorado por Git
- [ ] RLS activado en `beats`, `beat_licenses` y `admins`
- [ ] Registro público desactivado
- [ ] Primer admin insertado en `public.admins`
- [ ] Buckets `covers` y `audio` existen y solo el admin escribe
